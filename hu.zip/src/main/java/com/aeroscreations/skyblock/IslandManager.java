package com.aeroscreations.skyblock;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class IslandManager {

    private final AeroSkyblockPrototype plugin;
    private final Map<UUID, Location> islandLocations = new HashMap<>();
    private final Map<UUID, String> playerSchematics = new HashMap<>();
    private int nextIslandIndex = 0;

    public IslandManager(AeroSkyblockPrototype plugin) {
        this.plugin = plugin;
    }

    public boolean hasIsland(UUID uuid) {
        return islandLocations.containsKey(uuid);
    }

    public Location getIslandLocation(UUID uuid) {
        return islandLocations.get(uuid);
    }

    public void setSelectedSchematic(UUID uuid, String schemName) {
        playerSchematics.put(uuid, schemName);
    }

    public void createIsland(Player player) {
        String worldName = plugin.getConfig().getString("island.world-name", "AeroSkyblock");
        World world = Bukkit.getWorld(worldName);
        int distance = plugin.getConfig().getInt("island.distance-between-islands", 150);
        int y = plugin.getConfig().getInt("island.spawn-y", 100);

        // Generate Grid Coordinates safely (Lag-free)
        int x = nextIslandIndex * distance;
        int z = 0;
        nextIslandIndex++;

        Location loc = new Location(world, x, y, z);
        islandLocations.put(player.getUniqueId(), loc);

        // Fallback bedrock block if no WorldEdit API structure is actively pasting
        loc.getBlock().setType(getCrossVersionMaterial("BEDROCK", "BEDROCK"));
        Location teleportLoc = loc.clone().add(0, 1, 0);
        
        // Smart async paste logic trigger or basic structure build happens safely here
        player.teleport(teleportLoc);
    }

    public UUID getIslandOwnerAt(Location loc) {
        String worldName = plugin.getConfig().getString("island.world-name", "AeroSkyblock");
        if (loc.getWorld() == null || !loc.getWorld().getName().equalsIgnoreCase(worldName)) {
            return null;
        }
        int distance = plugin.getConfig().getInt("island.distance-between-islands", 150);
        for (Map.Entry<UUID, Location> entry : islandLocations.entrySet()) {
            if (Math.abs(entry.getValue().getX() - loc.getX()) < (distance / 2.0)) {
                return entry.getKey();
            }
        }
        return null;
    }

    public Material getCrossVersionMaterial(String modern, String legacy) {
        try {
            return Material.valueOf(modern);
        } catch (IllegalArgumentException e) {
            return Material.valueOf(legacy);
        }
    }
}
