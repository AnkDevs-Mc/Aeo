package com.aeroscreations.skyblock;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.UUID;

public class SkyblockExpansion extends PlaceholderExpansion {

    private final AeroSkyblockPrototype plugin;
    private final IslandManager islandManager;

    public SkyblockExpansion(AeroSkyblockPrototype plugin, IslandManager islandManager) {
        this.plugin = plugin;
        this.islandManager = islandManager;
    }

    @Override
    public String getIdentifier() {
        return "island";
    }

    @Override
    public String getAuthor() {
        return "Aero's Creations";
    }

    @Override
    public String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (params.equalsIgnoreCase("owner")) {
            if (player != null && player.isOnline()) {
                Player onlinePlayer = player.getPlayer();
                UUID ownerUUID = islandManager.getIslandOwnerAt(onlinePlayer.getLocation());
                
                if (ownerUUID == null) {
                    return "No Island";
                }
                if (ownerUUID.equals(onlinePlayer.getUniqueId())) {
                    return "Your Island";
                } else {
                    OfflinePlayer owner = Bukkit.getOfflinePlayer(ownerUUID);
                    return (owner.getName() != null ? owner.getName() : "Unknown") + "'s Island";
                }
            }
        }
        return null;
    }
}
