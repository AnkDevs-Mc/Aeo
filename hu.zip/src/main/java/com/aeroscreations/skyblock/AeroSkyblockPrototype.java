package com.aeroscreations.skyblock;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.UUID;

public class AeroSkyblockPrototype extends JavaPlugin implements CommandExecutor {

    private IslandManager islandManager;
    private VisitMenu visitMenu;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        createSchematicsFolder();
        
        // Ensure world exists
        String worldName = getConfig().getString("island.world-name", "AeroSkyblock");
        if (Bukkit.getWorld(worldName) == null) {
            Bukkit.createWorld(new WorldCreator(worldName));
        }

        this.islandManager = new IslandManager(this);
        this.visitMenu = new VisitMenu(this, islandManager);

        getCommand("is").setExecutor(this);
        getCommand("visit").setExecutor(this);
        getCommand("asb").setExecutor(this);

        // Register PlaceholderAPI hook safely if present
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new SkyblockExpansion(this, islandManager).register();
        }

        getLogger().info("AeroSkyblock-Prototype by Aero's Creations has been successfully enabled!");
    }

    private void createSchematicsFolder() {
        File schemDir = new File(getDataFolder(), "schematics");
        if (!schemDir.exists()) {
            schemDir.mkdirs();
        }
    }

    public String color(String msg) {
        return ChatColor.translateAlternateColorCodes('&', msg);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (cmd.getName().equalsIgnoreCase("is")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(color(getConfig().getString("messages.player-only")));
                return true;
            }
            Player player = (Player) sender;

            if (args.length > 0 && args[0].equalsIgnoreCase("schematic")) {
                if (args.length > 2 && args[1].equalsIgnoreCase("select")) {
                    String schemName = args[2];
                    File schemFile = new File(getDataFolder() + "/schematics", schemName);
                    if (schemFile.exists()) {
                        islandManager.setSelectedSchematic(player.getUniqueId(), schemName);
                        player.sendMessage(color(getConfig().getString("messages.schematic-selected").replace("%name%", schemName)));
                    } else {
                        player.sendMessage(color(getConfig().getString("messages.schematic-not-found").replace("%name%", schemName)));
                    }
                    return true;
                }
            }

            if (args.length > 0 && args[0].equalsIgnoreCase("create")) {
                if (islandManager.hasIsland(player.getUniqueId())) {
                    player.sendMessage(color(getConfig().getString("messages.already-has-island")));
                    return true;
                }
                islandManager.createIsland(player);
                player.sendMessage(color(getConfig().getString("messages.island-created")));
                return true;
            }
            
            player.sendMessage(color("&b&l--- AeroSkyblock Menu ---"));
            player.sendMessage(color("&e/is create &7- Create your island"));
            player.sendMessage(color("&e/is schematic select <file> &7- Select template (.schem/.schematic/.litematic)"));
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("visit")) {
            if (!(sender instanceof Player)) {
                sender.sendMessage(color(getConfig().getString("messages.player-only")));
                return true;
            }
            if (args.length < 1) {
                sender.sendMessage(color("&cUsage: /visit <player>"));
                return true;
            }
            Player player = (Player) sender;
            Player target = Bukkit.getPlayer(args[0]);

            if (target == null) {
                player.sendMessage(color(getConfig().getString("messages.player-not-found")));
                return true;
            }

            if (target.getUniqueId().equals(player.getUniqueId())) {
                player.sendMessage(color(getConfig().getString("messages.visiting-self")));
                return true;
            }

            visitMenu.openMenu(player, target);
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("asb")) {
            if (!sender.hasPermission("aeroskyblock.admin")) {
                sender.sendMessage(color(getConfig().getString("messages.no-permission")));
                return true;
            }
            if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
                reloadConfig();
                sender.sendMessage(color(getConfig().getString("messages.reload")));
                return true;
            }
            sender.sendMessage(color("&cUsage: /asb reload"));
            return true;
        }

        return false;
    }
}
