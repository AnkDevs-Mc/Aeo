package com.aeroscreations.skyblock;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.UUID;

public class VisitMenu implements Listener {

    private final AeroSkyblockPrototype plugin;
    private final IslandManager islandManager;

    public VisitMenu(AeroSkyblockPrototype plugin, IslandManager islandManager) {
        this.plugin = plugin;
        this.islandManager = islandManager;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void openMenu(Player player, Player target) {
        String title = plugin.color(plugin.getConfig().getString("gui.visit-menu.title").replace("%player%", target.getName()));
        int size = plugin.getConfig().getInt("gui.visit-menu.rows", 3) * 9;
        Inventory inv = Bukkit.createInventory(null, size, title);

        // Fill Item setup
        String fillMatName = plugin.getConfig().getString("gui.visit-menu.fill-item", "BLACK_STAINED_GLASS_PANE");
        ItemStack glass = new ItemStack(islandManager.getCrossVersionMaterial(fillMatName, "STAINED_GLASS_PANE"), 1, (short) 15);
        ItemMeta glassMeta = glass.getItemMeta();
        if (glassMeta != null) {
            glassMeta.setDisplayName(" ");
            glass.setItemMeta(glassMeta);
        }

        for (int i = 0; i < inv.getSize(); i++) {
            inv.setItem(i, glass);
        }

        // Skull Item setup with fallback handling across all versions
        ItemStack skull = new ItemStack(islandManager.getCrossVersionMaterial("PLAYER_HEAD", "SKULL_ITEM"), 1, (short) 3);
        SkullMeta skullMeta = (SkullMeta) skull.getItemMeta();
        if (skullMeta != null) {
            skullMeta.setOwner(target.getName());
            skullMeta.setDisplayName(plugin.color("&aVisit " + target.getName()));
            skull.setItemMeta(skullMeta);
        }

        int headSlot = plugin.getConfig().getInt("gui.visit-menu.head-slot", 13);
        inv.setItem(headSlot, skull);

        player.openInventory(inv);
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().contains("Visit ")) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null || event.getCurrentItem().getType() == Material.AIR) return;

            Player player = (Player) event.getWhoClicked();
            int headSlot = plugin.getConfig().getInt("gui.visit-menu.head-slot", 13);

            if (event.getSlot() == headSlot) {
                String targetName = event.getView().getTitle().replace(plugin.color(plugin.getConfig().getString("gui.visit-menu.title").replace("%player%", "")), "").trim();
                Player target = Bukkit.getPlayer(targetName);

                if (target == null) {
                    player.sendMessage(plugin.color(plugin.getConfig().getString("messages.player-not-found")));
                    player.closeInventory();
                    return;
                }

                if (!islandManager.hasIsland(target.getUniqueId())) {
                    player.sendMessage(plugin.color(plugin.getConfig().getString("messages.no-island-to-visit")));
                    player.closeInventory();
                    return;
                }

                player.closeInventory();
                player.sendMessage(plugin.color(plugin.getConfig().getString("messages.teleporting").replace("%owner%", target.getName())));
                player.teleport(islandManager.getIslandLocation(target.getUniqueId()).clone().add(0, 1, 0));
                
                target.sendMessage(plugin.color(plugin.getConfig().getString("messages.visiting-broadcast").replace("%player%", player.getName())));
            }
        }
    }
}
