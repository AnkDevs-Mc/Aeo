package com.aero.friends;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ConnectionListener implements Listener {
    private final AeroFriends plugin;
    public ConnectionListener(AeroFriends plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        FriendManager fm = plugin.getFriendManager();
        fm.updateLastSeen(player.getUniqueId(), 0L);

        String raw = plugin.getConfig().getString("messages.friend-join", "&9Friend &8> &7%player_name% &ejoined.");
        raw = raw.replace("%player_name%", player.getName());

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            raw = PlaceholderAPI.setPlaceholders(player, raw);
        }
        String finalizedMsg = ChatColor.translateAlternateColorCodes('&', raw);

        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (fm.isFriend(onlinePlayer.getUniqueId(), player.getName())) {
                onlinePlayer.sendMessage(finalizedMsg);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        FriendManager fm = plugin.getFriendManager();
        fm.updateLastSeen(player.getUniqueId(), System.currentTimeMillis());

        String raw = plugin.getConfig().getString("messages.friend-quit", "&9Friend &8> &7%player_name% &eleft.");
        raw = raw.replace("%player_name%", player.getName());

        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            raw = PlaceholderAPI.setPlaceholders(player, raw);
        }
        String finalizedMsg = ChatColor.translateAlternateColorCodes('&', raw);

        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (fm.isFriend(onlinePlayer.getUniqueId(), player.getName())) {
                onlinePlayer.sendMessage(finalizedMsg);
            }
        }
    }
}
