package com.aeroscreations.skyblock;

import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

public class SkyblockCommand implements CommandExecutor {

    private final AeroSkyblock plugin;

    public SkyblockCommand(AeroSkyblock plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Players only.");
            return true;
        }

        if (args.length == 0) {
            player.sendMessage("§e/is create §7- Create your island");
            player.sendMessage("§e/is schematic select <file.schem> §7- Select schematic");
            return true;
        }

        if (args[0].equalsIgnoreCase("create")) {
            plugin.getIslandManager().createIsland(player);
            return true;
        }

        if (args[0].equalsIgnoreCase("schematic") && args.length >= 3 && args[1].equalsIgnoreCase("select")) {
            String schemName = args[2];
            plugin.getIslandManager().selectSchematic(player, schemName);
            return true;
        }

        return false;
    }
}