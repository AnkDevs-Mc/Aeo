package com.aeroscreations.skyblock;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.generator.ChunkGenerator;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public class AeroSkyblock extends JavaPlugin {

    private static AeroSkyblock instance;
    private IslandManager islandManager;
    private SchematicManager schematicManager;
    private World skyblockWorld;

    @Override
    public void onEnable() {
        instance = this;
        
        // Setup Folders
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        File schemFolder = new File(getDataFolder(), "schematics");
        if (!schemFolder.exists()) schemFolder.mkdirs();

        // Create/Load Void World
        WorldCreator wc = new WorldCreator("aeroskyblock_world");
        wc.generator(new VoidGenerator());
        skyblockWorld = Bukkit.createWorld(wc);

        // Initialize Managers
        schematicManager = new SchematicManager(this);
        islandManager = new IslandManager(this);

        // Register Commands
        getCommand("is").setExecutor(new SkyblockCommand(this));
        getCommand("visit").setExecutor(new VisitCommand(this));

        // Register PAPI Expansion
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new SkyblockExpansion(this).register();
        }

        getLogger().info("AeroSkyblock-Prototype enabled successfully! Author: Aero's Creations");
    }

    @Override
    public void onDisable() {
        islandManager.saveData();
    }

    public static AeroSkyblock getInstance() { return instance; }
    public IslandManager getIslandManager() { return islandManager; }
    public SchematicManager getSchematicManager() { return schematicManager; }
    public World getSkyblockWorld() { return skyblockWorld; }
}