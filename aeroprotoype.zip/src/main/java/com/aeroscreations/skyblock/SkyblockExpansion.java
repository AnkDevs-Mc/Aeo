package com.aeroscreations.skyblock;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.UUID;

public class SkyblockExpansion extends PlaceholderExpansion {

    private final AeroSkyblock plugin;

    public SkyblockExpansion(AeroSkyblock plugin) {
        this.plugin = plugin;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "aeroskyblock"; 
    }

    @Override
    public @NotNull String getAuthor() {
        return "Aero's Creations";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true; 
    }

    @Override
    public String onRequest(OfflinePlayer offlinePlayer, @NotNull String params) {
        if (offlinePlayer == null || !offlinePlayer.isOnline()) return "";
        Player player = offlinePlayer.getPlayer();

        if (params.equalsIgnoreCase("island_owner")) {
            UUID ownerId = plugin.getIslandManager().getIslandOwnerAt(player.getLocation());
            
            if (ownerId == null) {
                return "Wilderness";
            }
            
            if (ownerId.equals(player.getUniqueId())) {
                return "Your Island";
            } else {
                OfflinePlayer owner = Bukkit.getOfflinePlayer(ownerId);
                String ownerName = owner.getName() != null ? owner.getName() : "Unknown";
                return ownerName + " Island";
            }
        }
        return null;
    }
}