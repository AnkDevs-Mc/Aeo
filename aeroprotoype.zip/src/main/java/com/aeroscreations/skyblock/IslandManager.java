package com.aeroscreations.skyblock;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class IslandManager {
    
    private final AeroSkyblock plugin;
    private final Map<UUID, Location> islands = new HashMap<>();
    private final Map<UUID, String> selectedSchematics = new HashMap<>();
    private final File dataFile;
    private FileConfiguration dataConfig;
    private int islandCount = 0;
    private final int ISLAND_SPACING = 1000;

    public IslandManager(AeroSkyblock plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "data.yml");
        loadData();
    }

    public void createIsland(Player player) {
        if (islands.containsKey(player.getUniqueId())) {
            player.sendMessage("§cYou already have an island! Teleporting you there...");
            player.teleport(islands.get(player.getUniqueId()));
            return;
        }

        String schematicName = selectedSchematics.getOrDefault(player.getUniqueId(), "default.schem");
        File schemFile = new File(plugin.getDataFolder() + "/schematics", schematicName);
        
        if (!schemFile.exists()) {
            player.sendMessage("§cSchematic " + schematicName + " not found in the schematics folder!");
            return;
        }

        // Calculate next grid location
        islandCount++;
        int x = islandCount * ISLAND_SPACING;
        int z = 0; // Keeping it simple on a linear axis for the prototype
        Location islandLoc = new Location(plugin.getSkyblockWorld(), x, 64, z);

        // Paste schematic async-friendly via WE API
        plugin.getSchematicManager().pasteSchematic(schemFile, islandLoc);

        // Save and teleport
        islands.put(player.getUniqueId(), islandLoc);
        saveData();
        
        player.teleport(islandLoc);
        player.sendMessage("§aYour island has been created using " + schematicName + "!");
    }

    public void selectSchematic(Player player, String schematicName) {
        File schemFile = new File(plugin.getDataFolder() + "/schematics", schematicName);
        if (!schemFile.exists()) {
            player.sendMessage("§cThat schematic does not exist!");
            return;
        }
        selectedSchematics.put(player.getUniqueId(), schematicName);
        player.sendMessage("§aSelected schematic: " + schematicName);
    }

    public void visitIsland(Player player, Player target) {
        if (!islands.containsKey(target.getUniqueId())) {
            player.sendMessage("§c" + target.getName() + " does not have an island.");
            return;
        }
        player.teleport(islands.get(target.getUniqueId()));
        player.sendMessage("§aVisiting " + target.getName() + "'s island.");
    }

    public UUID getIslandOwnerAt(Location loc) {
        if (!loc.getWorld().equals(plugin.getSkyblockWorld())) return null;
        
        for (Map.Entry<UUID, Location> entry : islands.entrySet()) {
            // If within 500 blocks (half of 1000 spacing), they are in this island's region
            if (entry.getValue().distance(loc) < (ISLAND_SPACING / 2.0)) {
                return entry.getKey();
            }
        }
        return null;
    }

    private void loadData() {
        if (!dataFile.exists()) return;
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        islandCount = dataConfig.getInt("islandCount", 0);
        
        if (dataConfig.contains("islands")) {
            for (String uuidStr : dataConfig.getConfigurationSection("islands").getKeys(false)) {
                UUID uuid = UUID.fromString(uuidStr);
                Location loc = dataConfig.getLocation("islands." + uuidStr);
                islands.put(uuid, loc);
            }
        }
    }

    public void saveData() {
        if (dataConfig == null) dataConfig = new YamlConfiguration();
        dataConfig.set("islandCount", islandCount);
        for (Map.Entry<UUID, Location> entry : islands.entrySet()) {
            dataConfig.set("islands." + entry.getKey().toString(), entry.getValue());
        }
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}