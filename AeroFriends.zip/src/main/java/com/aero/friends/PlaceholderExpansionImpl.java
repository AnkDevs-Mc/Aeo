package com.aero.friends;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;

public class PlaceholderExpansionImpl extends PlaceholderExpansion {
    private final AeroFriends plugin;
    public PlaceholderExpansionImpl(AeroFriends plugin) { this.plugin = plugin; }
    @Override public String getIdentifier() { return "friends"; }
    @Override public String getAuthor() { return "Aero's Creations"; }
    @Override public String getVersion() { return "1.0.0"; }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer player, String params) {
        if (player == null) return "0";
        FriendManager fm = plugin.getFriendManager();
        switch (params.toLowerCase()) {
            case "total": return String.valueOf(fm.getFriendsCount(player.getUniqueId()));
            case "online": return String.valueOf(fm.getOnlineFriendsCount(player.getUniqueId()));
            case "offline": return String.valueOf(fm.getOfflineFriendsCount(player.getUniqueId()));
            case "limit": return String.valueOf(plugin.getConfig().getInt("settings.max-friends-limit", 100));
        }
        return null;
    }
}
