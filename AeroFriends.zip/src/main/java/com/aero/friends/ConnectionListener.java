package com.aero.friends;

import me.clip.placeholderapi.PlaceholderAPI;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ConnectionListener implements Listener {
    private final AeroFriends plugin;

    public ConnectionListener(AeroFriends plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        FriendManager fm = plugin.getFriendManager();
        
        // Reset last seen timestamp cache
        fm.updateLastSeen(player.getUniqueId(), 0L);

        // Fetch dynamic context parameters from config
        String joinMsgTemplate = plugin.getConfig().getString("messages.friend-join", "&9Friend &8> &7{player} &ejoined.");
        joinMsgTemplate = joinMsgTemplate.replace("{player}", player.getName());

        // Dynamic Soft-Dependency parsing for internal placeholders (e.g., player ranks/prefixes/suffixes)
        String finalizedMsg = color(joinMsgTemplate);
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            finalizedMsg = PlaceholderAPI.setPlaceholders(player, finalizedMsg);
        }

        // Loop over network entities to notify their active friends exclusively
        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (fm.isFriend(onlinePlayer.getUniqueId(), player.getName())) {
                onlinePlayer.sendMessage(finalizedMsg);
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        FriendManager fm = plugin.getFriendManager();
        
        // Save current timestamp to evaluate offline counters later
        fm.updateLastSeen(player.getUniqueId(), System.currentTimeMillis());

        String quitMsgTemplate = plugin.getConfig().getString("messages.friend-quit", "&9Friend &8> &7{player} &eleft.");
        quitMsgTemplate = quitMsgTemplate.replace("{player}", player.getName());

        String finalizedMsg = color(quitMsgTemplate);
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            finalizedMsg = PlaceholderAPI.setPlaceholders(player, finalizedMsg);
        }

        for (Player onlinePlayer : Bukkit.getOnlinePlayers()) {
            if (fm.isFriend(onlinePlayer.getUniqueId(), player.getName())) {
                onlinePlayer.sendMessage(finalizedMsg);
            }
        }
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
