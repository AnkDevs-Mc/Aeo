package com.aero.friends;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class ConnectionListener implements Listener {
    private final AeroFriends plugin;
    public ConnectionListener(AeroFriends plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        plugin.getFriendManager().updateLastSeen(event.getPlayer().getUniqueId(), 0L);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getFriendManager().updateLastSeen(event.getPlayer().getUniqueId(), System.currentTimeMillis());
    }
}
