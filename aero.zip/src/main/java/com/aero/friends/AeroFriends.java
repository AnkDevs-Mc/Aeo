package com.aero.friends;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class AeroFriends extends JavaPlugin {
    private FriendManager friendManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        this.friendManager = new FriendManager(this);
        this.friendManager.loadData();
        getCommand("friend").setExecutor(new FriendCommand(this));
        getServer().getPluginManager().registerEvents(new ConnectionListener(this), this);
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new PlaceholderExpansionImpl(this).register();
        }
    }

    @Override
    public void onDisable() {
        if (this.friendManager != null) {
            this.friendManager.saveData();
        }
    }

    public FriendManager getFriendManager() {
        return friendManager;
    }
}
