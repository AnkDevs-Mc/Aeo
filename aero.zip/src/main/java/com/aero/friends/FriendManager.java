package com.aero.friends;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.*;

public class FriendManager {
    private final AeroFriends plugin;
    private File dataFile;
    private FileConfiguration dataConfig;
    private final Map<UUID, List<String>> friendsMap = new HashMap<>();
    private final Map<UUID, List<String>> requestsMap = new HashMap<>();
    private final Set<UUID> disabledRequests = new HashSet<>();
    private final Map<UUID, Long> lastSeenMap = new HashMap<>();

    public FriendManager(AeroFriends plugin) { this.plugin = plugin; }

    public void loadData() {
        dataFile = new File(plugin.getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            try { dataFile.getParentFile().mkdirs(); dataFile.createNewFile(); } catch (IOException e) { e.printStackTrace(); }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        if (dataConfig.getConfigurationSection("friends") != null) {
            for (String key : dataConfig.getConfigurationSection("friends").getKeys(false)) {
                friendsMap.put(UUID.fromString(key), dataConfig.getStringList("friends." + key));
            }
        }
        if (dataConfig.getConfigurationSection("requests") != null) {
            for (String key : dataConfig.getConfigurationSection("requests").getKeys(false)) {
                requestsMap.put(UUID.fromString(key), dataConfig.getStringList("requests." + key));
            }
        }
        for (String s : dataConfig.getStringList("disabled-toggles")) { disabledRequests.add(UUID.fromString(s)); }
        if (dataConfig.getConfigurationSection("lastseen") != null) {
            for (String key : dataConfig.getConfigurationSection("lastseen").getKeys(false)) {
                lastSeenMap.put(UUID.fromString(key), dataConfig.getLong("lastseen." + key));
            }
        }
    }

    public void saveData() {
        dataConfig.set("friends", null); dataConfig.set("requests", null); dataConfig.set("disabled-toggles", null); dataConfig.set("lastseen", null);
        for (Map.Entry<UUID, List<String>> entry : friendsMap.entrySet()) { dataConfig.set("friends." + entry.getKey().toString(), entry.getValue()); }
        for (Map.Entry<UUID, List<String>> entry : requestsMap.entrySet()) { dataConfig.set("requests." + entry.getKey().toString(), entry.getValue()); }
        List<String> toggles = new ArrayList<>();
        for (UUID id : disabledRequests) { toggles.add(id.toString()); }
        dataConfig.set("disabled-toggles", toggles);
        for (Map.Entry<UUID, Long> entry : lastSeenMap.entrySet()) { dataConfig.set("lastseen." + entry.getKey().toString(), entry.getValue()); }
        try { dataConfig.save(dataFile); } catch (IOException e) { e.printStackTrace(); }
    }

    public List<String> getFriends(UUID uuid) { return friendsMap.computeIfAbsent(uuid, k -> new ArrayList<>()); }
    public List<String> getIncomingRequests(UUID uuid) { return requestsMap.computeIfAbsent(uuid, k -> new ArrayList<>()); }
    public void addFriend(UUID p1, UUID p2, String n1, String n2) { getFriends(p1).add(n2); getFriends(p2).add(n1); }
    public void removeFriend(UUID p1, UUID p2, String n1, String n2) { getFriends(p1).remove(n2); getFriends(p2).remove(n1); }
    @SuppressWarnings("deprecation")
    public void removeAllFriends(UUID uuid) {
        List<String> currentFriends = new ArrayList<>(getFriends(uuid));
        String myName = Bukkit.getOfflinePlayer(uuid).getName();
        for(String friendName : currentFriends) {
            UUID fUUID = Bukkit.getOfflinePlayer(friendName).getUniqueId();
            removeFriend(uuid, fUUID, myName, friendName);
        }
    }
    public boolean isFriend(UUID p1, String name2) { return getFriends(p1).contains(name2); }
    public boolean hasRequestToggleDisabled(UUID uuid) { return disabledRequests.contains(uuid); }
    public void toggleRequests(UUID uuid) { if (disabledRequests.contains(uuid)) disabledRequests.remove(uuid); else disabledRequests.add(uuid); }
    public void updateLastSeen(UUID uuid, Long time) { lastSeenMap.put(uuid, time); }
    public long getLastSeen(UUID uuid) { return lastSeenMap.getOrDefault(uuid, 0L); }
    public int getFriendsCount(UUID uuid) { return getFriends(uuid).size(); }
    public int getOnlineFriendsCount(UUID uuid) {
        int count = 0;
        for (String name : getFriends(uuid)) { if (Bukkit.getPlayer(name) != null && Bukkit.getPlayer(name).isOnline()) count++; }
        return count;
    }
    public int getOfflineFriendsCount(UUID uuid) { return getFriendsCount(uuid) - getOnlineFriendsCount(uuid); }
}
