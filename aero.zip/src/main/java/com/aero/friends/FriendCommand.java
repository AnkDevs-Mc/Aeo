package com.aero.friends;

import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class FriendCommand implements CommandExecutor {
    private final AeroFriends plugin;
    private final List<String> subCommands = Arrays.asList("add", "remove", "list", "help", "toggle", "removeall", "accept", "deny", "requests");

    public FriendCommand(AeroFriends plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage("Only players can manage friends.");
            return true;
        }

        Player player = (Player) sender;
        FriendManager fm = plugin.getFriendManager();
        String divider = color(plugin.getConfig().getString("messages.chat-divider"));

        if (args.length == 0) {
            sendHelpMessage(player, divider);
            return true;
        }

        String sub = args[0].toLowerCase();

        // Support direct /f <playername> to send an invite instantly
        if (!subCommands.contains(sub) && args.length == 1) {
            handleRequestSend(player, args[0], fm);
            return true;
        }

        switch (sub) {
            case "help":
                sendHelpMessage(player, divider);
                break;
            case "add":
                if (args.length < 2) {
                    player.sendMessage(color("&cUsage: /friend add <player>"));
                    return true;
                }
                handleRequestSend(player, args[1], fm);
                break;
            case "accept":
                if (args.length < 2) {
                    player.sendMessage(color("&cUsage: /friend accept <player>"));
                    return true;
                }
                handleAccept(player, args[1], fm);
                break;
            case "deny":
                if (args.length < 2) {
                    player.sendMessage(color("&cUsage: /friend deny <player>"));
                    return true;
                }
                handleDeny(player, args[1], fm);
                break;
            case "remove":
                if (args.length < 2) {
                    player.sendMessage(color("&cUsage: /friend remove <player>"));
                    return true;
                }
                handleRemove(player, args[1], fm);
                break;
            case "toggle":
                fm.toggleRequests(player.getUniqueId());
                boolean disabled = fm.hasRequestToggleDisabled(player.getUniqueId());
                player.sendMessage(color(plugin.getConfig().getString(disabled ? "messages.request-toggle-off" : "messages.request-toggle-on")));
                break;
            case "removeall":
                fm.removeAllFriends(player.getUniqueId());
                player.sendMessage(color(plugin.getConfig().getString("messages.removed-all")));
                break;
            case "list":
                int page = 1;
                if (args.length >= 2) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException e) {
                        page = 1;
                    }
                }
                handleListDisplay(player, fm, page, divider);
                break;
            default:
                sendHelpMessage(player, divider);
                break;
        }
        return true;
    }

    private void sendHelpMessage(Player player, String divider) {
        player.sendMessage(divider);
        player.sendMessage(color(plugin.getConfig().getString("messages.help-header")));
        for (String line : plugin.getConfig().getStringList("messages.help-lines")) {
            player.sendMessage(color(line));
        }
        player.sendMessage(divider);
    }

    @SuppressWarnings("deprecation")
    private void handleRequestSend(Player sender, String targetName, FriendManager fm) {
        if (sender.getName().equalsIgnoreCase(targetName)) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.cannot-friend-self")));
            return;
        }
        if (fm.isFriend(sender.getUniqueId(), targetName)) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.already-friends")));
            return;
        }

        int limit = plugin.getConfig().getInt("settings.max-friends-limit");
        if (fm.getFriendsCount(sender.getUniqueId()) >= limit) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.limit-reached").replace("{limit}", String.valueOf(limit))));
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        if (target == null || (!target.hasPlayedBefore() && !target.isOnline())) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.player-not-found")));
            return;
        }

        if (fm.hasRequestToggleDisabled(target.getUniqueId())) {
            sender.sendMessage(color(plugin.getConfig().getString("messages.requests-disabled-target")));
            return;
        }

        fm.getIncomingRequests(target.getUniqueId()).add(sender.getName());
        sender.sendMessage(color(plugin.getConfig().getString("messages.request-sent").replace("{player}", targetName)));
        
        if (target.isOnline()) {
            Player targetPlayer = (Player) target;
            String div = color(plugin.getConfig().getString("messages.chat-divider"));
            targetPlayer.sendMessage(div);
            targetPlayer.sendMessage(color(plugin.getConfig().getString("messages.request-received-header").replace("{player}", sender.getName())));
            
            TextComponent acceptBtn = new TextComponent(ChatColor.GREEN + "" + ChatColor.BOLD + "[ACCEPT] ");
            acceptBtn.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/f accept " + sender.getName()));
            acceptBtn.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(color(plugin.getConfig().getString("messages.request-hover-accept").replace("{player}", sender.getName()))).create()));
            
            TextComponent denyBtn = new TextComponent(ChatColor.RED + "" + ChatColor.BOLD + "[DENY]");
            denyBtn.setClickEvent(new ClickEvent(ClickEvent.Action.RUN_COMMAND, "/f deny " + sender.getName()));
            denyBtn.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder(color(plugin.getConfig().getString("messages.request-hover-deny").replace("{player}", sender.getName()))).create()));
            
            TextComponent combined = new TextComponent("");
            combined.addExtra(acceptBtn);
            combined.addExtra(denyBtn);
            
            targetPlayer.spigot().sendMessage(combined);
            targetPlayer.sendMessage(div);
        }
    }

    @SuppressWarnings("deprecation")
    private void handleAccept(Player player, String targetName, FriendManager fm) {
        if (!fm.getIncomingRequests(player.getUniqueId()).contains(targetName)) {
            player.sendMessage(color(plugin.getConfig().getString("messages.no-request")));
            return;
        }

        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        fm.getIncomingRequests(player.getUniqueId()).remove(targetName);
        fm.addFriend(player.getUniqueId(), target.getUniqueId(), player.getName(), targetName);

        player.sendMessage(color(plugin.getConfig().getString("messages.request-accepted").replace("{player}", targetName)));
        if (target.isOnline()) {
            ((Player) target).sendMessage(color(plugin.getConfig().getString("messages.request-accepted").replace("{player}", player.getName())));
        }
    }

    private void handleDeny(Player player, String targetName, FriendManager fm) {
        if (fm.getIncomingRequests(player.getUniqueId()).remove(targetName)) {
            player.sendMessage(color(plugin.getConfig().getString("messages.request-denied").replace("{player}", targetName)));
        } else {
            player.sendMessage(color(plugin.getConfig().getString("messages.no-request")));
        }
    }

    @SuppressWarnings("deprecation")
    private void handleRemove(Player player, String targetName, FriendManager fm) {
        if (!fm.isFriend(player.getUniqueId(), targetName)) {
            player.sendMessage(color(plugin.getConfig().getString("messages.not-friends")));
            return;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(targetName);
        fm.removeFriend(player.getUniqueId(), target.getUniqueId(), player.getName(), targetName);
        
        // Notify sender screen
        player.sendMessage(color(plugin.getConfig().getString("messages.removed-friend-sender").replace("{player}", targetName)));
        
        // Dynamic active alert mapping: Notify target player screen simultaneously if they are currently online
        if (target.isOnline()) {
            ((Player) target).sendMessage(color(plugin.getConfig().getString("messages.removed-friend-target").replace("{player}", player.getName())));
        }
    }

    @SuppressWarnings("deprecation")
    private void handleListDisplay(Player player, FriendManager fm, int page, String divider) {
        List<String> friends = fm.getFriends(player.getUniqueId());
        if (friends.isEmpty()) {
            player.sendMessage(divider);
            player.sendMessage(color(plugin.getConfig().getString("messages.list-empty")));
            player.sendMessage(divider);
            return;
        }

        int perPage = plugin.getConfig().getInt("settings.friends-per-page", 8);
        int maxPage = (int) Math.ceil((double) friends.size() / perPage);
        if (page < 1) page = 1;
        if (page > maxPage) page = maxPage;

        player.sendMessage(divider);
        player.sendMessage(color(plugin.getConfig().getString("messages.list-header")
                .replace("{page}", String.valueOf(page))
                .replace("{max_page}", String.valueOf(maxPage))));

        int start = (page - 1) * perPage;
        int end = Math.min(start + perPage, friends.size());

        for (int i = start; i < end; i++) {
            String fName = friends.get(i);
            Player fPlayer = Bukkit.getPlayer(fName);
            if (fPlayer != null && fPlayer.isOnline()) {
                // Tracking active game-state session across server/world structures dynamically
                String locationName = fPlayer.getWorld().getName();
                player.sendMessage(color(plugin.getConfig().getString("messages.list-format-online")
                        .replace("{player}", fName)
                        .replace("{location}", locationName)));
            } else {
                OfflinePlayer offlineFriend = Bukkit.getOfflinePlayer(fName);
                long offlineTime = fm.getLastSeen(offlineFriend.getUniqueId());
                player.sendMessage(color(plugin.getConfig().getString("messages.list-format-offline")
                        .replace("{player}", fName)
                        .replace("{duration}", formatTime(offlineTime))));
            }
        }
        player.sendMessage(divider);
    }

    private String formatTime(long timestamp) {
        if (timestamp == 0) return "1d 4h"; 
        long diff = System.currentTimeMillis() - timestamp;
        long minutes = (diff / (1000 * 60)) % 60;
        long hours = (diff / (1000 * 60 * 60)) % 24;
        long days = diff / (1000 * 60 * 60 * 24);
        
        if (days > 0) return days + "d " + hours + "h";
        if (hours > 0) return hours + "h " + minutes + "m";
        return minutes + "m";
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }
}
